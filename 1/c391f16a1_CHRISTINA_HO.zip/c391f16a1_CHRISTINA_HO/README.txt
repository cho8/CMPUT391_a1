CMPUT391
Fall2016
Christina Ho

For each question, simply use:
	make q[n]
where [n] is the question number.

Each compilation will result in an a.out file. 
Please also provide a database filename when you execute a.out. If the .db file doesn't exist it will be created.
	./a.out <database.db>



No collaborations were made for this assignment.